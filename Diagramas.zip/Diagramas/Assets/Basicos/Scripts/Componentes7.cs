using UnityEngine;
using UnityEngine.UIElements;

public class Componentes7 : MonoBehaviour
{
    /*
    Dados dos GameObjects intercambiar sus posiciones (usar
 Transform y la variable position)*/
    public GameObject[] Objectos;
    public void Awake()
    {
        Vector3 posicionObjeto1, posicionObjeto2;
        posicionObjeto1 = Objectos[0].transform.position;
        posicionObjeto2 = Objectos[1].transform.position;
        Debug.Log($"El objeto {Objectos[0].name} tiene la posicion {posicionObjeto1}");
        Debug.Log($"El objeto {Objectos[1].name} tiene la posicion {posicionObjeto2}");

        Debug.LogWarning("Cambiamos las posiciones");


        posicionObjeto1 = Objectos[1].transform.position;
        posicionObjeto2 = Objectos[0].transform.position;
        //Con esto cambiamos la posicion en la escena;no solo los valores que devuelve la consola
        Objectos[0].transform.position = posicionObjeto1;
        Objectos[1].transform.position = posicionObjeto2;

        Debug.Log($"La nueva posicion del {Objectos[0].name} es {posicionObjeto1}");
        Debug.Log($"La nueva posicion del {Objectos[1].name} es {posicionObjeto2}");

    }
}
