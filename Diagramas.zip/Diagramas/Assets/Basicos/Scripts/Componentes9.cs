using UnityEngine;

public class Componentes9 : MonoBehaviour
{
    /*Dado un array de GameObjects, activar solo aquellos cuyo spriteRenderer tenga
     forma de círculo (nombre del Sprite contenga “Circle”)*/
    [SerializeField] GameObject[] Objetos2D;
    void Awake()
    {
        foreach (var Circulos in Objetos2D)
        {
            if (Circulos.GetComponent<SpriteRenderer>().sprite.name == "Circle")
            {
                Circulos.SetActive(true);
            }
            else
            {
                Circulos.SetActive(false);
            }
        }
    }

}
